#include <stdlib.h>
#include <unistd.h>
#include <stdio.h>

void remove_later() 
{
   printf("You have found my weakness!\n");
}

void foo() {
   
    char buf[19];
    printf("Address of buf is at %p\n", buf);
    scanf("%s",buf);
}
int main()
{
    foo();

    return 0;
}
